import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'
import { generateWeekdaySlots } from '@/lib/utils'

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url)
  const date = searchParams.get('date')
  const serviceId = searchParams.get('serviceId')

  if (!date || !serviceId) {
    return NextResponse.json({ error: 'date ja serviceId vaaditaan.' }, { status: 400 })
  }

  const { data: settings } = await supabaseAdmin
    .from('business_settings')
    .select('calendar_enabled, booking_lead_minutes')
    .eq('id', 1)
    .single()

  if (settings && !settings.calendar_enabled) {
    return NextResponse.json({ slots: [] })
  }

  const { data: service, error: serviceError } = await supabaseAdmin
    .from('services')
    .select('id, duration_minutes')
    .eq('id', serviceId)
    .single()

  if (serviceError || !service) {
    return NextResponse.json({ error: 'Palvelua ei löytynyt.' }, { status: 404 })
  }

  const selectedDate = new Date(`${date}T12:00:00`)
  const slots = generateWeekdaySlots(selectedDate, service.duration_minutes)

  const leadMinutes = settings?.booking_lead_minutes || 60
  const minAllowed = new Date(Date.now() + leadMinutes * 60 * 1000)

  const validSlots = slots.filter((slot) => slot.startsAt >= minAllowed)

  const dayStart = validSlots[0]?.startsAt.toISOString()
  const dayEnd = validSlots[validSlots.length - 1]?.endsAt.toISOString()

  if (!dayStart || !dayEnd) {
    return NextResponse.json({ slots: [] })
  }

  const nowIso = new Date().toISOString()

  const [{ data: bookings }, { data: closures }] = await Promise.all([
    supabaseAdmin
      .from('bookings')
      .select('starts_at, ends_at, status, reservation_expires_at')
      .or(`status.eq.confirmed,and(status.eq.pending_payment,reservation_expires_at.gt.${nowIso})`)
      .lt('starts_at', dayEnd)
      .gt('ends_at', dayStart),
    supabaseAdmin
      .from('closures')
      .select('starts_at, ends_at')
      .lt('starts_at', dayEnd)
      .gt('ends_at', dayStart)
  ])

  const filtered = validSlots.filter((slot) => {
    const blockedByBooking = (bookings || []).some((b: any) => {
      const bs = new Date(b.starts_at)
      const be = new Date(b.ends_at)
      return slot.startsAt < be && slot.endsAt > bs
    })

    const blockedByClosure = (closures || []).some((c: any) => {
      const cs = new Date(c.starts_at)
      const ce = new Date(c.ends_at)
      return slot.startsAt < ce && slot.endsAt > cs
    })

    return !blockedByBooking && !blockedByClosure
  })

  return NextResponse.json({
    slots: filtered.map((slot) => ({
      startsAt: slot.startsAt.toISOString(),
      endsAt: slot.endsAt.toISOString(),
      label: slot.label
    }))
  })
}
