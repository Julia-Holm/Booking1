import { NextRequest, NextResponse } from 'next/server'
import { addMinutes } from 'date-fns'
import { supabaseAdmin } from '@/lib/supabaseAdmin'

export async function POST(request: NextRequest) {
  const body = await request.json()
  const { customerName, customerEmail, customerPhone, serviceId, startsAt } = body

  if (!customerName || !serviceId || !startsAt) {
    return NextResponse.json({ error: 'Pakollisia tietoja puuttuu.' }, { status: 400 })
  }

  const { data: service, error: serviceError } = await supabaseAdmin
    .from('services')
    .select('id, duration_minutes, price_eur, deposit_eur')
    .eq('id', serviceId)
    .single()

  if (serviceError || !service) {
    return NextResponse.json({ error: 'Palvelua ei löytynyt.' }, { status: 404 })
  }

  const start = new Date(startsAt)
  const end = addMinutes(start, service.duration_minutes)
  const expires = addMinutes(new Date(), 15)
  const paymentReference = `JH-${Date.now()}`

  const { data, error } = await supabaseAdmin
    .from('bookings')
    .insert({
      customer_name: customerName,
      customer_email: customerEmail || null,
      customer_phone: customerPhone || null,
      service_id: service.id,
      starts_at: start.toISOString(),
      ends_at: end.toISOString(),
      status: 'pending_payment',
      reservation_expires_at: expires.toISOString(),
      deposit_eur: service.deposit_eur,
      price_eur: service.price_eur,
      remaining_eur: service.price_eur - service.deposit_eur,
      payment_reference: paymentReference
    })
    .select('id, reservation_expires_at, payment_reference, deposit_eur, remaining_eur, price_eur')
    .single()

  if (error) {
    return NextResponse.json({ error: 'Aika ehti varatuksi tai lukituksi toiselle.' }, { status: 409 })
  }

  const { data: settings } = await supabaseAdmin
    .from('business_settings')
    .select('bank_account, mobilepay_name, mobilepay_number, business_address, arrival_instructions, cancellation_policy')
    .eq('id', 1)
    .single()

  return NextResponse.json({
    booking: data,
    payment: {
      bankAccount: settings?.bank_account,
      mobilepayName: settings?.mobilepay_name,
      mobilepayNumber: settings?.mobilepay_number,
      depositEur: data.deposit_eur,
      reference: data.payment_reference
    },
    visit: {
      address: settings?.business_address,
      arrivalInstructions: settings?.arrival_instructions
    },
    policy: settings?.cancellation_policy
  })
}
