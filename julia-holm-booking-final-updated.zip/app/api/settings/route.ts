import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabaseAdmin'

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from('business_settings')
    .select('business_name, city, business_address, arrival_instructions, bank_account, mobilepay_name, mobilepay_number, cancellation_policy, calendar_enabled, booking_lead_minutes')
    .eq('id', 1)
    .single()

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({ settings: data })
}
