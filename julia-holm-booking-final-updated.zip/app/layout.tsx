export const metadata = {
  title: 'Julia Holm | Ajanvaraus',
  description: 'Ajanvaraus Porissa'
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fi">
      <body style={{ margin: 0, background: '#0d0d11', color: '#f3f0ea', fontFamily: 'Inter, Arial, sans-serif' }}>
        {children}
      </body>
    </html>
  )
}
