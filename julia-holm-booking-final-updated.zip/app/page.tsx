export default function Home() {
  return (
    <main style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 24 }}>
      <section style={{ maxWidth: 980, width: '100%', display: 'grid', gap: 24, gridTemplateColumns: '1.2fr 1fr' }}>
        <div style={{ padding: 32, border: '1px solid rgba(255,255,255,0.1)', borderRadius: 28, background: 'linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02))' }}>
          <p style={{ letterSpacing: '0.2em', textTransform: 'uppercase', color: '#c7b8a3', margin: 0 }}>Pori</p>
          <h1 style={{ fontSize: 54, lineHeight: 1, margin: '18px 0 12px' }}>Julia Holm</h1>
          <p style={{ fontSize: 18, color: '#d8d0c4', maxWidth: 520 }}>
            Tyylikäs ja selkeä ajanvaraus. Aika lukitaan 15 minuutiksi varausmaksun suorittamista varten.
          </p>
          <a href="/booking" style={{ display: 'inline-block', marginTop: 22, textDecoration: 'none', background: '#efe3d0', color: '#111', padding: '14px 20px', borderRadius: 14, fontWeight: 700 }}>
            Avaa kalenteri
          </a>
        </div>

        <div style={{ padding: 32, border: '1px solid rgba(255,255,255,0.1)', borderRadius: 28, background: 'rgba(255,255,255,0.03)' }}>
          <h2 style={{ marginTop: 0 }}>Palvelut</h2>
          <div style={{ display: 'grid', gap: 12 }}>
            <div>15 min · 100 €</div>
            <div>30 min · 150 €</div>
            <div>60 min · 250 €</div>
          </div>
          <p style={{ marginTop: 22, color: '#d8d0c4' }}>
            Varausmaksu 50 € maksetaan aikaa varatessa. Se hyvitetään tapaamisen hinnasta.
          </p>
          <p style={{ color: '#d8d0c4' }}>
            Varausmaksua ei palauteta mikäli tapaaminen peruuntuu asiakkaan toimesta.
          </p>
        </div>
      </section>
    </main>
  )
}
