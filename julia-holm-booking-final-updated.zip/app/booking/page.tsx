'use client'

import Calendar from 'react-calendar'
import 'react-calendar/dist/Calendar.css'
import { useEffect, useMemo, useState } from 'react'

type Service = {
  id: string
  name: string
  duration_minutes: number
  price_eur: number
  deposit_eur: number
}

type Slot = {
  startsAt: string
  endsAt: string
  label: string
}

export default function BookingPage() {
  const [date, setDate] = useState<Date>(new Date())
  const [services, setServices] = useState<Service[]>([])
  const [serviceId, setServiceId] = useState('')
  const [slots, setSlots] = useState<Slot[]>([])
  const [selectedSlot, setSelectedSlot] = useState('')
  const [customerName, setCustomerName] = useState('')
  const [customerEmail, setCustomerEmail] = useState('')
  const [customerPhone, setCustomerPhone] = useState('')
  const [settings, setSettings] = useState<any>(null)
  const [result, setResult] = useState<any>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    fetch('/api/services').then((res) => res.json()).then((data) => {
      setServices(data.services || [])
      if (data.services?.[0]?.id) setServiceId(data.services[0].id)
    })
    fetch('/api/settings').then((res) => res.json()).then((data) => setSettings(data.settings))
  }, [])

  const dateKey = useMemo(() => {
    const y = date.getFullYear()
    const m = String(date.getMonth() + 1).padStart(2, '0')
    const d = String(date.getDate()).padStart(2, '0')
    return `${y}-${m}-${d}`
  }, [date])

  useEffect(() => {
    if (!serviceId) return
    fetch(`/api/availability?date=${dateKey}&serviceId=${serviceId}`)
      .then((res) => res.json())
      .then((data) => setSlots(data.slots || []))
  }, [serviceId, dateKey])

  const currentService = services.find((s) => s.id === serviceId)

  async function submitBooking() {
    setError('')
    setResult(null)

    const response = await fetch('/api/bookings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        customerName,
        customerEmail,
        customerPhone,
        serviceId,
        startsAt: selectedSlot
      })
    })

    const data = await response.json()
    if (!response.ok) {
      setError(data.error || 'Varaus ei onnistunut.')
      return
    }
    setResult(data)
  }

  return (
    <main style={{ minHeight: '100vh', padding: 24 }}>
      <div style={{ maxWidth: 1180, margin: '0 auto', display: 'grid', gap: 24, gridTemplateColumns: '1.1fr 0.9fr' }}>
        <section style={{ padding: 24, borderRadius: 24, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <h1 style={{ marginTop: 0 }}>Ajanvaraus</h1>
          <p style={{ color: '#d8d0c4' }}>Arkisin 16:00–23:00 · Ajan voi varata aikaisintaan tunnin päähän.</p>

          <div style={{ marginTop: 18 }}>
            <label>Palvelu</label>
            <select
              value={serviceId}
              onChange={(e) => setServiceId(e.target.value)}
              style={{ width: '100%', marginTop: 8, padding: 14, borderRadius: 12, background: '#15151a', color: '#f3f0ea', border: '1px solid rgba(255,255,255,0.08)' }}
            >
              {services.map((service) => (
                <option key={service.id} value={service.id}>
                  {service.name} · {service.price_eur} €
                </option>
              ))}
            </select>
          </div>

          <div style={{ marginTop: 18 }}>
            <Calendar onChange={(v) => setDate(v as Date)} value={date} minDate={new Date()} />
          </div>

          <div style={{ marginTop: 18 }}>
            <label>Vapaat ajat</label>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, minmax(0, 1fr))', gap: 10, marginTop: 10 }}>
              {slots.map((slot) => {
                const active = selectedSlot === slot.startsAt
                return (
                  <button
                    key={slot.startsAt}
                    type="button"
                    onClick={() => setSelectedSlot(slot.startsAt)}
                    style={{
                      padding: 12,
                      borderRadius: 12,
                      border: active ? '1px solid #efe3d0' : '1px solid rgba(255,255,255,0.08)',
                      background: active ? '#efe3d0' : '#15151a',
                      color: active ? '#111' : '#f3f0ea',
                      cursor: 'pointer'
                    }}
                  >
                    {slot.label}
                  </button>
                )
              })}
            </div>
          </div>

          <div style={{ display: 'grid', gap: 12, marginTop: 22 }}>
            <input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder="Nimi" style={{ padding: 14, borderRadius: 12, background: '#15151a', color: '#f3f0ea', border: '1px solid rgba(255,255,255,0.08)' }} />
            <input value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} placeholder="Sähköposti" style={{ padding: 14, borderRadius: 12, background: '#15151a', color: '#f3f0ea', border: '1px solid rgba(255,255,255,0.08)' }} />
            <input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="Puhelin" style={{ padding: 14, borderRadius: 12, background: '#15151a', color: '#f3f0ea', border: '1px solid rgba(255,255,255,0.08)' }} />
          </div>

          <button
            type="button"
            onClick={submitBooking}
            disabled={!selectedSlot || !customerName || !serviceId}
            style={{ marginTop: 22, padding: '14px 18px', borderRadius: 14, background: '#efe3d0', color: '#111', border: 0, fontWeight: 700, cursor: 'pointer' }}
          >
            Lukitse aika 15 minuutiksi
          </button>

          {error ? <p style={{ color: '#ffb3b3' }}>{error}</p> : null}
        </section>

        <aside style={{ padding: 24, borderRadius: 24, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)' }}>
          <h2 style={{ marginTop: 0 }}>Yhteenveto</h2>
          <p>Palvelu: {currentService ? `${currentService.name} · ${currentService.price_eur} €` : 'Valitse palvelu'}</p>
          <p>Varausmaksu: 50 €</p>
          <p>Maksettavaa tapaamisella: {currentService ? `${currentService.price_eur - 50} €` : '-'}</p>
          <p style={{ color: '#d8d0c4' }}>Varausmaksua ei palauteta mikäli tapaaminen peruuntuu asiakkaan toimesta.</p>

          {result ? (
            <div style={{ marginTop: 22, padding: 18, borderRadius: 18, background: '#15151a' }}>
              <h3 style={{ marginTop: 0 }}>Maksa 15 minuutin sisällä</h3>
              <p>Viite: <b>{result.booking.payment_reference}</b></p>
              <p>Varausmaksu: <b>{result.payment.depositEur} €</b></p>
              <p>MobilePay: <b>{result.payment.mobilepayNumber}</b> ({result.payment.mobilepayName})</p>
              <p>Tilinumero: <b>{result.payment.bankAccount}</b></p>
              <p>Osoite: <b>{result.visit.address}</b></p>
              <p>Saapumisohjeet: <b>{result.visit.arrivalInstructions}</b></p>
              <p>Varaus vahvistetaan, kun maksu on merkitty vastaanotetuksi.</p>
              <p>Aika lukittu asti: <b>{new Date(result.booking.reservation_expires_at).toLocaleString('fi-FI')}</b></p>
            </div>
          ) : (
            <div style={{ marginTop: 22, padding: 18, borderRadius: 18, background: '#15151a' }}>
              <p style={{ margin: 0, color: '#d8d0c4' }}>
                Kun varaus luodaan, järjestelmä lukitsee ajan 15 minuutiksi maksun suorittamista varten.
              </p>
            </div>
          )}
        </aside>
      </div>
    </main>
  )
}
