import { supabaseAdmin } from '@/lib/supabaseAdmin'

export default async function AdminPage() {
  const { data: settings } = await supabaseAdmin
    .from('business_settings')
    .select('calendar_enabled')
    .eq('id', 1)
    .single()

  const { data: bookings } = await supabaseAdmin
    .from('bookings')
    .select('id, customer_name, customer_phone, starts_at, status, reservation_expires_at, payment_reference, remaining_eur, deposit_eur')
    .order('starts_at', { ascending: true })

  return (
    <main style={{ padding: 24, minHeight: '100vh' }}>
      <div style={{ maxWidth: 1080, margin: '0 auto' }}>
        <h1>Admin</h1>
        <p>Kalenteri: {settings?.calendar_enabled ? 'Auki' : 'Suljettu'}</p>

        <div style={{ display: 'grid', gap: 12 }}>
          {(bookings || []).map((booking: any) => (
            <div key={booking.id} style={{ padding: 16, borderRadius: 16, background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)' }}>
              <div><b>{booking.customer_name}</b> · {new Date(booking.starts_at).toLocaleString('fi-FI')}</div>
              <div>Tila: {booking.status}</div>
              <div>Viite: {booking.payment_reference}</div>
              <div>Varausmaksu: {booking.deposit_eur} € · Loppu: {booking.remaining_eur} €</div>
              {booking.reservation_expires_at ? <div>Lukitus päättyy: {new Date(booking.reservation_expires_at).toLocaleString('fi-FI')}</div> : null}
            </div>
          ))}
        </div>
      </div>
    </main>
  )
}
