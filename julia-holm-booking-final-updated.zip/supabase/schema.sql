create extension if not exists btree_gist;

create type booking_status as enum (
  'pending_payment',
  'confirmed',
  'cancelled',
  'expired'
);

create table if not exists services (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  duration_minutes integer not null check (duration_minutes > 0),
  price_eur integer not null check (price_eur > 0),
  deposit_eur integer not null default 50,
  active boolean not null default true,
  sort_order integer not null default 0
);

insert into services (name, duration_minutes, price_eur, deposit_eur, sort_order)
values
  ('15 min', 15, 100, 50, 1),
  ('30 min', 30, 150, 50, 2),
  ('60 min', 60, 250, 50, 3)
on conflict do nothing;

create table if not exists business_settings (
  id integer primary key default 1,
  business_name text not null default 'Julia Holm',
  city text not null default 'Pori',
  business_address text not null default 'Kalskeentie 6-8 B 26, Pori',
  arrival_instructions text not null default 'Koululla on parkkipaikkoja, muista parkkikiekko!',
  bank_account text not null default 'FI45 5106 0120 1382 29',
  mobilepay_name text not null default 'Kiilholma',
  mobilepay_number text not null default '0404120866',
  cancellation_policy text not null default 'Varausmaksua ei palauteta mikäli tapaaminen peruuntuu asiakkaan toimesta.',
  calendar_enabled boolean not null default true,
  booking_lead_minutes integer not null default 60,
  updated_at timestamptz not null default now(),
  check (id = 1)
);

insert into business_settings (id)
values (1)
on conflict (id) do nothing;

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  customer_email text,
  customer_phone text,
  service_id uuid not null references services(id),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  status booking_status not null default 'pending_payment',
  reservation_expires_at timestamptz,
  deposit_eur integer not null default 50,
  price_eur integer not null,
  remaining_eur integer not null,
  payment_reference text not null,
  payment_received_at timestamptz,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create table if not exists closures (
  id uuid primary key default gen_random_uuid(),
  starts_at timestamptz not null,
  ends_at timestamptz not null,
  reason text,
  created_at timestamptz not null default now(),
  check (ends_at > starts_at)
);

create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists bookings_set_updated_at on bookings;
create trigger bookings_set_updated_at
before update on bookings
for each row execute function set_updated_at();

drop trigger if exists business_settings_set_updated_at on business_settings;
create trigger business_settings_set_updated_at
before update on business_settings
for each row execute function set_updated_at();
